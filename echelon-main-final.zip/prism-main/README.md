# Echelon

## Introduction

Welcome to the Echelon Project! This project base on LLM to provide powerful AI search capabilities. 

With Echelon, you can easily verify each answer in real time by checking live references, giving you confidence in the answers.

## Try with Echelon

Below are screenshots of our products

![img.png](docs/img/img.png)

## Architecture

![img.png](docs/img/arch.png)

## Key Features

- The answers can be traced back through references
- Visualize the answer using a mind map
- A wealth of references sources are currently supported, including X (Twitter) and Google Search.
- Built-in observability based on Opentelemetry
- Fully asynchronous supported
- Concurrent retrieval
- 


## Contributing
